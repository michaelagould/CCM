public class Program3
{
	public static void main(String[] args)
	{
	System.out.println("    *\n\n  * * *\n\n* * * * *");
	}
}