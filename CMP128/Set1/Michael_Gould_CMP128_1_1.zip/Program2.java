public class Program2
{
	public static void main(String[] args)
	{
	System.out.println("    *\n");
	System.out.println("  * * *\n");
	System.out.println("* * * * *");
	}
}