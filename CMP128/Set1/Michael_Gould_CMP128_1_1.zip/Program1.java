public class Program1
{
	public static void main(String[] args)
	{
	System.out.println("Michael Gould");
	System.out.println("75 Davenport Road");
	System.out.println("Montville NJ 07045");
	}
}