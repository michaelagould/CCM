public class Program4
{
	public static void main(String[] args)
	{
	System.out.println("Part\t\t" + "Description\t\t\t" + "Price");
	System.out.println("----\t\t" + "-----------\t\t\t" + "-----");
	System.out.println("1-03\t\t" + "Albeits' tomography set \t" + "$ 100.33");
	System.out.println("99-3\t\t" + "CTS \"cellular\" scanner \t\t" + "$  50.43");
	System.out.println("32-1\t\t" + "Liputose monitor \t\t" + "$ 200.17");
	
	}
}